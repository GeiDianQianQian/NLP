#!/usr/bin/env python
import optparse
import sys
import models
from collections import namedtuple
import itertools

optparser = optparse.OptionParser()
optparser.add_option("-i", "--input", dest="input", default="../data/input",
                     help="File containing sentences to translate (default=data/input)")
optparser.add_option("-t", "--translation-model", dest="tm", default="../data/tm",
                     help="File containing translation model (default=data/tm)")
optparser.add_option("-l", "--language-model", dest="lm", default="../data/lm",
                     help="File containing ARPA-format language model (default=data/lm)")
optparser.add_option("-n", "--num_sentences", dest="num_sents", default=sys.maxint, type="int",
                     help="Number of sentences to decode (default=no limit)")
optparser.add_option("-k", "--translations-per-phrase", dest="k", default=1, type="int",
                     help="Limit on number of translations to consider per phrase (default=1)")
optparser.add_option("-s", "--stack-size", dest="s", default=1, type="int", help="Maximum stack size (default=1)")
optparser.add_option("-v", "--verbose", dest="verbose", action="store_true", default=False,
                     help="Verbose mode (default=off)")
opts = optparser.parse_args()[0]

tm = models.TM(opts.tm, opts.k)
lm = models.LM(opts.lm)
french = [tuple(line.strip().split()) for line in open(opts.input).readlines()[:opts.num_sents]]

# tm should translate unknown words as-is with probability 1
for word in set(sum(french, ())):
    if (word,) not in tm:
        tm[(word,)] = [models.phrase(word, 0.0)]

sys.stderr.write("Decoding %s...\n" % (opts.input,))
for num, f in enumerate(french):
    # The following code implements a monotone decoding
    # algorithm (one that doesn't permute the target phrases).
    # Hence all hypotheses in stacks[i] represent translations of
    # the first i words of the input sentence. You should generalize
    # this so that they can represent translations of *any* i words.
    hypothesis = namedtuple("hypothesis", "logprob, lm_state, predecessor, phrase, f")
    initial_hypothesis = hypothesis(0.0, lm.begin(), None, None, None)
    stacks = [{} for _ in f] + [{}]
    stacks[0][lm.begin()] = initial_hypothesis
    for i, stack in enumerate(stacks[:-1]):
        for h in sorted(stack.itervalues(), key=lambda h: -h.logprob)[:1000]:  # prune
            for j in xrange(i + 1, len(f) + 1):
                if f[i:j] in tm:
                    for phrase in tm[f[i:j]]:
                        logprob = h.logprob + phrase.logprob
                        lm_state = h.lm_state
                        for word in phrase.english.split():
                            (lm_state, word_logprob) = lm.score(lm_state, word)
                            logprob += word_logprob
                        logprob += lm.end(lm_state) if j == len(f) else 0.0
                        new_hypothesis = hypothesis(logprob, lm_state, h, phrase, f[i:j])
                        if lm_state not in stacks[j] or stacks[j][
                            lm_state].logprob < logprob:  # second case is recombination
                            stacks[j][lm_state] = new_hypothesis
    winner = max(stacks[-1].itervalues(), key=lambda h: h.logprob)


    def extract_english_phrases(h, arr, english):
        if h.predecessor is None:
            return arr
        else:
            arr.append(h.phrase.english) if english else arr.append(h.f)
            return extract_english_phrases(h.predecessor, arr, english)


    def extract_english(h):
        return "" if h.predecessor is None else "%s%s " % (extract_english(h.predecessor), h.phrase.english)


    def score(arr):
        logprob = 0.0
        auxArr = arr[:]
        auxArr.insert(0, lm.begin()[0])
        for i, word in enumerate(auxArr[:-1]):
            try:
                (lm_state, word_logprob) = lm.score(tuple(word.split()[-2:]), auxArr[i + 1].split()[0])
                logprob += word_logprob
            except:
                logprob += -6
        return logprob


    def swap(arr, s):
        best = arr[:]
        bests = s
        changed = False
        perms=[]
        for i in range(len(arr[:-5])):
            for j in xrange(i + 1, len(arr[:-4])):
                for k in xrange(j + 1, len(arr[:-3])):
                    for l in xrange(k + 1, len(arr[:-2])):
                        ind_array=[i, j, k, l]
                        permutations = list(itertools.permutations(ind_array, len(ind_array)))
                        for n in permutations:
                            aux = arr[:]
                            aux[i], aux[j], aux[k], aux[l] = aux[n[0]], aux[n[1]], aux[n[2]], aux[n[3]]
                            perms.append(aux)

        best = arr[:]
        bests = s
        changed = False
        for it in perms:
            sc=score(it)
            if sc>bests:
                bests = sc
                best = it
                changed = True

        return (best, bests, changed)


    def best_perm(current):
        best=current
        bests=score(current)
        perms=list(itertools.permutations(current, len(current)))
        for perm in perms:
            sc= score(list(perm))
            if sc>bests:
                bests = sc
                best = perm
        return best

    def improve(h):
        current = extract_english_phrases(winner, [], True)[::-1]
        # currentF = extract_english_phrases(winner, [], False)[::-1]
        if len(current)<4:
            return best_perm(current)
        while True:
            s_current = score(current)
            (current, s_current, c1) = swap(current, s_current)
            if not c1:
                break
            #sys.stderr.write(str(s_current)+': '+ str(current)+'\n')
        return current

    sys.stderr.write('permuting: '+ str(num)+'\n')
    print " ".join(improve(winner))

    if opts.verbose:
        def extract_tm_logprob(h):
            return 0.0 if h.predecessor is None else h.phrase.logprob + extract_tm_logprob(h.predecessor)


        tm_logprob = extract_tm_logprob(winner)
        sys.stderr.write("LM = %f, TM = %f, Total = %f\n" %
                         (winner.logprob - tm_logprob, tm_logprob, winner.logprob))
